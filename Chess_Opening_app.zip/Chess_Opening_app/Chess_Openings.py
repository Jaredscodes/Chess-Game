import tkinter as tk                # python 3
from tkinter import font  as tkfont # python 3
import chess
import chess.svg
from Amazon_web_services import upload_game



class SampleApp(tk.Tk):

    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)

        self.title_font = tkfont.Font(family='Helvetica', size=18, weight="bold", slant="italic")

        # the container is where we'll stack a bunch of frames
        # on top of each other, then the one we want visible
        # will be raised above the others
        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for F in (Color_picker_page, Black_HomePage, White_HomePage, Add_New_Opening_Page):
            page_name = F.__name__
            frame = F(parent=container, controller=self)
            self.frames[page_name] = frame

            # put all of the pages in the same location;
            # the one on the top of the stacking order
            # will be the one that is visible.
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame("Color_picker_page")

    def show_frame(self, page_name):
        '''Show a frame for the given page name'''
        frame = self.frames[page_name]
        frame.tkraise()


class Color_picker_page(tk.Frame):
   def __init__(self, parent, controller):
       tk.Frame.__init__(self,parent)
       self.controller = controller
       l = tk.Label(self, text= 'Welcome to My Chess Openings')
       l.config(font=("Courier", 15))
       l1 = tk.Label(self, text="Choose a Color.")
       b1 = tk.Button(self, text="Black", bg = "black", fg = 'white', padx = 50, command=lambda: controller.show_frame("Black_HomePage") )
       b2 = tk.Button(self, text="White", bg = "white", fg ='black',padx = 50,command=lambda: controller.show_frame("White_HomePage") )
       b3 = tk.Button(self, text="Add an Opening", bg = "white", fg ='black',padx = 50, command=lambda: controller.show_frame("Add_New_Opening_Page")  )
       l.pack(side="top", fill="both")
       l1.pack(side="top", fill='both')
       b1.pack(side="left")
       b2.pack(side="right")
       b3.pack(side = "bottom")
       

class Black_HomePage(tk.Frame):
   def __init__(self, parent, controller):
       tk.Frame.__init__(self,parent)
       self.controller = controller
       label = tk.Label(self, text="This is page 2").grid(row = 0, column = 0)
       board = chess.BaseBoard()
       l2 = tk.Label(self, text = board).grid(row = 1, column = 1)


class White_HomePage(tk.Frame):
   def __init__(self, parent, controller):
       tk.Frame.__init__(self,parent)
       self.controller = controller
       label = tk.Label(self, text="This is page 3")
       label.pack(side="top", fill="both", expand=True)


class Add_New_Opening_Page(tk.Frame):
   def __init__(self, parent, controller):
       tk.Frame.__init__(self,parent)
       self.controller = controller
       l1 = tk.Label(self, text="Add Your Openings Here").grid(row = 0, column = 1)
       l0 = tk.Label(self,text = "Color").grid(row = 1)
       option_list = ("Black", "White")
       self.color = tk.StringVar()
       self.color.set(option_list[0])
       col = tk.OptionMenu(self,self.color, *option_list).grid(row = 1, column = 1)
       Tname = tk.Text(self, height=2, width=30).grid(row = 2, column = 1, pady = 20, padx = 10)
       l2 = tk.Label(self, text = "Name of The Opening").grid(row = 2, column = 0)
       TPGN = tk.Text(self, height=10, width=30,).grid(row = 3, column = 1)
       l3 = tk.Label(self, text = "PGN").grid(row = 3, column = 0)
       b1 = tk.Button(self, text = "Submit", command = upload_game(self.color, l2, TPGN)).grid(row = 4, column =1, pady = 10)
       
       
       

if __name__ == "__main__":
    app = SampleApp()
    app.wm_geometry("400x400")
    app.mainloop()