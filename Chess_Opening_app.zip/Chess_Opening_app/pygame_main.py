import pygame as p
import chess_Engine

WIDTH = HEIGHT = 512
dimension = 8
SQ_SIZE = HEIGHT//dimension
MAX_FPS = 15
IMAGES={}
p.init()
screen = p.display.set_mode((WIDTH+100, HEIGHT+100))
clock = p.time.Clock()

def load_Images():
    pieces = ['wp','wR','wN','wB','wQ','wK','bp','bR','bN','bB','bQ','bK']
    for piece in pieces:
        IMAGES[piece] = p.transform.scale(p.image.load('chess_images/'+ piece +'.png'), (SQ_SIZE,SQ_SIZE))

def intro():
    intro = True
    while intro:
        mx,my = p.mouse.get_pos()
        White_button = p.Rect(50, 100, 200, 50)
        Black_button = p.Rect(50, 200, 200, 50)
        p.draw.rect(screen,(255,0,0), White_button)
        p.draw.rect(screen,(255,0,0), Black_button)
        if White_button.collidepoint((mx,my)):
            if click:
                pass
        if Black_button.collidepoint((mx,my)):
            if click:
                pass
        click = False
        for event in p.event.get():
            if event.type == p.QUIT:
                p.quit
                quit()
            elif event.type == p.MOUSEBUTTONDOWN:
                if event.button == 1:
                    click = True

        screen.fill(p.Color('white'))
        largeText = p.font.Font('freesansbold.ttf', 50)
        TextSurf, TextRect = text_objects('Chess Journal',largeText)
        TextRect.center = ((WIDTH/2),HEIGHT/2-200)
        screen.blit(TextSurf, TextRect)
        p.display.update()
        p.display.update()
        clock.tick(15)



def main():
    screen.fill(p.Color("white"))
    gs = chess_Engine.Gamestate()
    validMoves = gs.GetValidMoves()
    MoveMade = False
    load_Images()
    running = True
    sq_selected = ()
    player_clicks = []
    while running:
        for e in p.event.get():
            if e.type == p.QUIT:
                running = False
            elif e.type == p.MOUSEBUTTONDOWN:
                location = p.mouse.get_pos()
                col = location[0] // SQ_SIZE
                row = location[1] // SQ_SIZE
                if sq_selected == (row,col):
                    sq_selected = ()
                    player_clicks = []
                else:
                    sq_selected = (row, col)
                    player_clicks.append(sq_selected)
                    if len(player_clicks) == 2:
                        Move = chess_Engine.move(player_clicks[0], player_clicks[1],gs.board)
                        if str(Move) in validMoves:
                            gs.MakeMove(Move)
                            MoveMade = True
                            sq_selected = ()
                            player_clicks = []
                        else:
                            player_clicks = [sq_selected]
            elif e.type == p.KEYDOWN:
                if e.key == p.K_LEFT:
                    gs.UndoMove()
                    MoveMade = True

            if MoveMade:
                validMoves = gs.GetValidMoves()
                MoveMade = False
                if gs.eng_board.is_checkmate():
                    gs.user_move_log.append(gs.eng_board.result())
                elif gs.eng_board.is_stalemate():
                    running = False
                elif gs.eng_board.is_check():
                    pass
            
        drawGamestate(screen, gs)
        clock.tick(MAX_FPS)
        p.display.flip()

def drawGamestate(screen, gs):
    drawBoard(screen)
    drawPieces(screen, gs.board)

def drawBoard(screen):
    colors = [p.Color('white'), p.Color('gray')]
    for r in range(dimension):
        for c in range(dimension):
            color = colors[((r+c) %2)]
            p.draw.rect(screen, color, p.Rect(c*SQ_SIZE, r*SQ_SIZE, SQ_SIZE, SQ_SIZE))

def text_objects(text, font):
    textSurface = font.render(text, True, p.Color('black'))
    return textSurface, textSurface.get_rect()

def drawPieces(screen, board):
    for r in range(dimension):
        for c in range(dimension):
            piece = board[r][c]
            if piece != "--":
                screen.blit(IMAGES[piece], p.Rect(c*SQ_SIZE, r*SQ_SIZE, SQ_SIZE, SQ_SIZE))   


main()