import boto3

dynamodb = boto3.resource('dynamodb',
    aws_access_key_id='AKIAI7J52GOBTK6OLGUQ',
    aws_secret_access_key='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', region_name = 'us-east-2'
)

White_database = dynamodb.Table("White")
Black_database = dynamodb.Table("Black")


def upload_game(Database, name, PGN):
    try:
        Database.put_item(
            Item = {
                "Name": name,
                "PGN" : PGN
            }
        )
        return True
    except:
        return False