from stockfish import Stockfish

stockfish = Stockfish("\\Users\\jared\\Python\\Chess_Opening_app\\stockfish-11-win")