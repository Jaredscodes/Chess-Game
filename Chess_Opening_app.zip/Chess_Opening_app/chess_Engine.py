import chess
import chess.engine
import asyncio




            




class Gamestate():
    def __init__(self):
        self.board = [
            ['bR','bN','bB','bQ','bK','bB','bN','bR'],
            ['bp','bp','bp','bp','bp','bp','bp','bp'],
            ['--','--','--','--','--','--','--','--'],
            ['--','--','--','--','--','--','--','--'],
            ['--','--','--','--','--','--','--','--'],
            ['--','--','--','--','--','--','--','--'],
            ['wp','wp','wp','wp','wp','wp','wp','wp'],
            ['wR','wN','wB','wQ','wK','wB','wN','wR']

        ]
        self.White_to_move = True
        self.movelog = []
        self.user_move_log = []
        self.pins = []
        self.checks = []
        self.eng_board = chess.Board()
        self.legal_moves = self.eng_board.legal_moves 
        self.RankstoRows = {'1':7, '2':6, '3': 5, '4': 4, '5': 3, '6': 2, '7':1, '8':0}
        self.RowstoRanks = {v:k for k, v in self.RankstoRows.items()}
        self.FilestoCols = {'a': 0,'b':1 ,'c': 2,'d': 3,'e': 4, 'f': 5, 'g': 6, 'h': 7}
        self.ColstoFiles = {v:k for k, v in self.FilestoCols.items()}
        self.en_passant = False
        self.white_castle = False
        self.black_castle = False

        
    async def evaluation(self) -> None:
            transport, engine = await chess.engine.popen_uci("\\Users\\jared\\Python\\Chess_Opening_app\\stockfish-11-win\\stockfish-11-win\\Windows\\stockfish_20011801_x64")
            info = await engine.analyse(self.eng_board, chess.engine.Limit(time=0.1))
            print(info['score'])
            await engine.quit()


    def MakeMove(self, move):
        self.board[move.startrow][move.startcol] = '--' 
        self.board[move.endrow][move.endcol] = move.piece_moved
        if self.eng_board.is_checkmate() and self.eng_board.is_check:
            self.user_move_log.append('#'+ str(move))
        elif self.eng_board.is_check():
            self.user_move_log.append(str(move) + '+')
        else:
            if self.White_to_move:
                if str(move) == 'Kg1' and move.startcol == 4 and move.startrow == 7: #White Kingside castle
                    self.white_castle = True
                    self.eng_board.push_san('O-O')
                    self.board[7][7] = '--'
                    self.board[7][5] = 'wR'
                    self.user_move_log.append('O-O')
                if not self.white_castle:
                    self.eng_board.push_san(str(move))
                    self.movelog.append(move)
                    self.user_move_log.append(str(move))

                
                
            else:
                if str(move) == 'Kg7' and move.startcol == 4 and move.startrow == 0: #Black Kingside castle
                    self.black_castle = True
                    self.eng_board.push_san('O-O')
                    self.board[0][7] = '--'
                    self.board[0][5] = 'wR'
                if not self.black_castle:
                    self.eng_board.push_san(str(move))
                    self.movelog.append(move)
                    self.user_move_log.append(str(move))
                
        self.White_to_move = not self.White_to_move
        asyncio.set_event_loop_policy(chess.engine.EventLoopPolicy())
        asyncio.run(self.evaluation())
        print(self.user_move_log)
        print(self.movelog)
        

    def UndoMove(self):
        if len(self.movelog) != 0:
            self.eng_board.pop()
            move = self.movelog.pop()
            user_move = self.user_move_log.pop()
            self.board[move.endrow][move.endcol] = move.piece_captured
            self.board[move.startrow][move.startcol] = move.piece_moved
            self.White_to_move = not self.White_to_move

    
    def GetValidMoves(self):
        moves = []
        piece_coordinates = []
        piece_captured_Coord = [] 
        for x in self.legal_moves:
            coord = str(x)
            if self.White_to_move:
                if coord == 'e1g1' and self.eng_board.has_kingside_castling_rights(1):
                    moves.append(coord)
            else:
                if coord == 'e8g8' and self.eng_board.has_kingside_castling_rights(0):
                    moves.append(coord)
            piece_coordinates.append((self.FilestoCols[coord[0]],self.RankstoRows[coord[1]])) #piece moved coordinates
            piece = self.board[piece_coordinates[0][1]][piece_coordinates[0][0]][1] #piece moved
            piece_captured_Coord.append(coord[2:]) #piece captured coord
            piece_check_col = self.FilestoCols[piece_captured_Coord[0][0]]
            piece_check_row = self.RankstoRows[piece_captured_Coord[0][1]]
            piece_captured = self.board[piece_check_row][piece_check_col] #piece captured
            if self.White_to_move:
                if piece == 'p':
                    if piece_captured == '--':
                        moves.append(piece_captured_Coord[0])
                    elif piece_captured[0] == 'b':
                        if piece_captured != 'bK':
                            move_1 = str(coord[0]) + 'x' + str(piece_captured_Coord[0])
                            moves.append(move_1)                         
                else:
                    if piece_captured == '--':
                        moves.append(piece+coord[2:])
                    elif piece_captured[0] == 'b':
                        if piece_captured != 'bK':
                            moves.append(piece + 'x' + str(piece_captured_Coord[0]))
                piece_captured_Coord.pop()
                piece_coordinates.pop()
            else:
                if piece == 'p':
                    if piece_captured == '--':
                        moves.append(piece_captured_Coord[0])
                    elif piece_captured[0] == 'w':
                        if piece_captured != 'wK':
                            move_1 = str(coord[0]) + 'x' + str(piece_captured_Coord[0])
                            moves.append(move_1)   
                else:
                    if piece_captured == '--':
                        moves.append(piece+coord[2:])
                    elif piece_captured[0] == 'w':
                        if piece_captured != 'wK':
                            moves.append(piece + 'x' + str(piece_captured_Coord[0]))
                piece_captured_Coord.pop()
                piece_coordinates.pop()
        return moves
            
            




    def CheckForPinAndCheck(self):
        pins = []
        checks  = []
        inCheck = False
       
        return inCheck, pins, checks






class move():
    RankstoRows = {'1':7, '2':6, '3': 5, '4': 4, '5': 3, '6': 2, '7':1, '8':0}
    RowstoRanks = {v:k for k, v in RankstoRows.items()}
    FilestoCols = {'a': 0,'b':1 ,'c': 2,'d': 3,'e': 4, 'f': 5, 'g': 6, 'h': 7}
    ColstoFiles = {v:k for k, v in FilestoCols.items()}
    def __init__(self, startsq, endsq, board):
        self.startcol = startsq[1]
        self.startrow = startsq[0]
        self.endcol = endsq[1]
        self.endrow = endsq[0]
        self.piece_moved = board[self.startrow][self.startcol]
        self.piece_captured = board[self.endrow][self.endcol]
        self.moveID = self.startrow *1000 + self.startcol * 100 + self.endrow * 10 + self.endcol
        self.check = False
        self.checkmate = False
    
    def __str__(self):
        return self.GetChessNotation()

    __repr__ = __str__


    def __eq__(self, other):
        if isinstance(other, move):
            return self.moveID == other.moveID
        return False

    def GetChessNotation(self):
        if self.piece_moved[1] == 'p':
            if self.piece_captured != '--':
                return self.ColstoFiles[self.startcol] + 'x' + self.GetRankFile(self.endrow,self.endcol)
            return self.GetRankFile(self.endrow,self.endcol)
        elif self.piece_captured != '--':
            return self.piece_moved[1] + 'x' + self.GetRankFile(self.endrow,self.endcol)
        return self.piece_moved[1] + self.GetRankFile(self.endrow,self.endcol)
        
     
    
    def GetRankFile(self, r, c):
        return self.ColstoFiles[c] + self.RowstoRanks[r]
